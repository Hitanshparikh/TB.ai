require('dotenv').config();

const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const session = require('express-session');

const app = express();
const port = 3000;

// Debugging: Verify environment variables
console.log('Google Client ID:', process.env.GOOGLE_CLIENT_ID);
console.log('Google Client Secret:', process.env.GOOGLE_CLIENT_SECRET);
console.log('Session Secret:', process.env.SESSION_SECRET);

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Session setup
app.use(session({
  secret: process.env.SESSION_SECRET, // Provide the secret directly here
  resave: false,
  saveUninitialized: true,
}));

// Initialize Passport
app.use(passport.initialize());
app.use(passport.session());

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD || '', // Use empty string if no password
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL database');
  }
});

// Passport Google OAuth2 Strategy
passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: 'http://localhost:3000/auth/google/callback',
}, (accessToken, refreshToken, profile, done) => {
  console.log('Google profile:', profile); // Debugging log
  // Check if the user already exists in your database
  const googleId = profile.id;
  const email = profile.emails[0].value;
  const name = profile.displayName;

  db.query('SELECT * FROM users WHERE google_id = ? OR email = ?', [googleId, email], (err, results) => {
    if (err) return done(err);

    if (results.length > 0) {
      // User already exists
      console.log('User already exists:', results[0]); // Debugging log
      return done(null, results[0]);
    } else {
      // Create a new user
      const newUser = {
        google_id: googleId,
        name: name,
        email: email,
        password: null, // No password for Google users
      };

      db.query('INSERT INTO users SET ?', newUser, (err, result) => {
        if (err) return done(err);
        newUser.id = result.insertId;
        console.log('New user created:', newUser); // Debugging log
        return done(null, newUser);
      });
    }
  });
}));

// Serialize and deserialize user
passport.serializeUser((user, done) => {
  console.log('Serializing user:', user); // Debugging log
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  console.log('Deserializing user with id:', id); // Debugging log
  db.query('SELECT * FROM users WHERE id = ?', [id], (err, results) => {
    if (err) return done(err);
    done(null, results[0]);
  });
});

// Google OAuth Routes
app.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.use(cors({
    origin: 'http://127.0.0.1:5500', // Allow requests from Live Server
    credentials: true, // Allow cookies/session
  }));

  const path = require('path');

// Serve static files from the root folder

app.get('/auth/google/callback',
    passport.authenticate('google', { failureRedirect: '/login' }),
    (req, res) => {
      // Successful authentication, redirect to the frontend
      res.redirect('http://127.0.0.1:5500/dashboard.html');
    }
  );

// Logout route
app.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      return res.status(500).json({ message: 'Error logging out' });
    }
    res.redirect('/login');
  });
});

// Registration route (for email/password registration)
app.post('/register', async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    // Check if user already exists
    const [existingUser] = await db.promise().query('SELECT * FROM users WHERE email = ?', [email]);
    if (existingUser.length > 0) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Insert new user into the database
    await db.promise().query('INSERT INTO users (name, email, password) VALUES (?, ?, ?)', [name, email, password]);

    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Login route (for email/password login)
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const [user] = await db.promise().query('SELECT * FROM users WHERE email = ? AND password = ?', [email, password]);
    if (user.length > 0) {
      // Log the user in
      req.login(user[0], (err) => {
        if (err) {
          return res.status(500).json({ message: 'Error logging in' });
        }
        res.status(200).json({ message: 'Login successful', user: user[0] });
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Protected route (example)
app.get('/profile', (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  res.json({ user: req.user });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});